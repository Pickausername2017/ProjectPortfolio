
print ("Welcome ot the Carbon Calculator" )
# User Creates and Names a text File 
userFilename = input ("Please enter a filename: ")
fileType = "txt"
fileName = userFilename + "." + fileType
file = open(fileName, "a")
file.write ("Welcome to the Carbon Calculator\n")
file.write ("Tree," + " Diameter,"+ " Height,"+ "Green Weight,"
            + "Dry Weight,"+ "Total Carbon Sequestered \n,")
#This section creates the list of heights and diameters.

treeCount = int( input ("Enter the total number of trees: "))
print ("Total Trees in Dataset:")
print (treeCount)
 
while treeCount > 0:
   TreeCir = float ( input ("Enter the Tree Circumference: ") )
   printTreeCir = str (TreeCir) 
   TreeHeight = float (input ("What is the Tree height: ") )
   printTreeHeight = str (TreeHeight) 
   TreeDiameter = (TreeCir)/3.14 
   if TreeDiameter < 11:
      W = ((.25*TreeDiameter**2*TreeHeight))
   elif TreeDiameter > 11:
      W = ((.15)* (TreeDiameter**2)*(TreeHeight))
   B = str (W) 
   # Total Green Weight  is GW = W*1.2  
   GW = W*1.2
   X = str(GW)

   #Total Dry Weight
   DW = GW* .725
   Y= str (DW) 

   #Carbon Weight , approximately 50% Of the dry weight of the tree 
   CW = DW*.5
   Z = str (CW) 


   #Total Carbon Dioxide Sequester
   TCS = CW*3.6663
   A = str (TCS) 
   
   #loop decrementer   
   treeCount = treeCount - 1
   
 
   
   #sets the initial value to one.
   ascendTreeCount = treeCount + 1 
   treecountPrint = str (ascendTreeCount)
  

  

   #writes the data to the text file 
   file.write  ("\n" + treecountPrint + "," + printTreeCir + ","
                + printTreeHeight +","  + X + "," + Y + ","  + A) 

file.close() 
  
